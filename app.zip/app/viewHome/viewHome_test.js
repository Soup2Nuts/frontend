'use strict';

describe('myApp.viewHome module', function() {

  beforeEach(module('myApp.viewHome'));

  describe('view1 controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var viewHomeCtrl = $controller('ViewHomeCtrl');
      expect(viewHomeCtrl).toBeDefined();
    }));

  });
});